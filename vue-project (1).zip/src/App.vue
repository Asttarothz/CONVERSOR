<template>
  <div class="converter-container">
    <h2>Conversor de Moeda</h2>

    <div class="input-group">
      <label>Valor em Real (R$)</label>
      <input type="number" v-model.number="valorReal" placeholder="Digite o valor" />
    </div>

    <button class="converter-btn" @click="converterMoeda">Converter para Dólar</button>

    <div v-if="resultado" class="resultado">
      <p>Resultado: <strong>{{ resultado }}</strong></p>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const valorReal = ref(null)
const resultado = ref('')

const taxaDolar = 0.18 // exemplo: R$1 = $0.18 USD

function converterMoeda() {
  if (valorReal.value && valorReal.value > 0) {
    const valorConvertido = valorReal.value * taxaDolar
    resultado.value = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(valorConvertido)
  } else {
    resultado.value = 'Digite um valor válido.'
  }
}
</script>

<style scoped>
.converter-container {
  max-width: 360px;
  margin: 0 auto;
  padding: 20px;
  background: #f0f9ff;
  border-radius: 20px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
  font-family: 'Arial Rounded MT Bold', sans-serif;
  color: #444;
}

h2 {
  text-align: center;
  color: #6a5acd;
  margin-bottom: 20px;
}

.input-group {
  margin-bottom: 15px;
}

label {
  font-weight: bold;
  display: block;
  margin-bottom: 5px;
  color: #5a5a5a;
}

input {
  width: 100%;
  padding: 10px;
  border: 2px solid #e0e0e0;
  border-radius: 12px;
  background: #fff;
  font-size: 1em;
}

.converter-btn {
  width: 100%;
  background: #b388ff;
  color: white;
  border: none;
  padding: 12px;
  border-radius: 25px;
  font-size: 1em;
  font-weight: bold;
  cursor: pointer;
  transition: background 0.3s;
}

.converter-btn:hover {
  background: #9f6bff;
}

.resultado {
  margin-top: 20px;
  text-align: center;
  font-size: 1.1em;
  background: #e0f7fa;
  padding: 10px;
  border-radius: 12px;
}
</style>

