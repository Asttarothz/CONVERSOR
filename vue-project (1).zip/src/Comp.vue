<template>
  <div class="comment-box">
    <h2>Comentários</h2>
    <div>
      <input v-model="novoComentario" placeholder="Escreva seu comentário" />
      <button @click="adicionarComentario">Enviar</button>
    </div>

    <ul>
      <li v-for="(comentario, index) in comentarios" :key="index">
        {{ comentario }}
      </li>
    </ul>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const novoComentario = ref('')
const comentarios = ref([])

function adicionarComentario() {
  if (novoComentario.value.trim() !== '') {
    comentarios.value.push(novoComentario.value.trim())
    novoComentario.value = ''
  }
}
</script>

<style scoped>
.comment-box {
  max-width: 400px;
  margin: 0 auto;
  font-family: Arial, sans-serif;
}
input {
  width: 70%;
  padding: 8px;
  margin-right: 5px;
}
button {
  padding: 8px 12px;
}
ul {
  margin-top: 20px;
  padding-left: 20px;
}
li {
  margin-bottom: 10px;
}
</style>

